<?php
namespace Anuchit@Naphon\UI;
use pocketmine\command\CommandSender;
use pocketmine\command\Command;
use pocketmine\plugin\PluginBase;
use pocketmine\Server;
use pocketmine\Player;
use Anuchit@Naphon\UI\tasks\Task1;


class Main extends PluginBase{


   public function onEnable(){
        $this->reloadConfig();
\n        // $this->getServer()->getScheduler()->scheduler<Delayed or Repeating>Task(new Task1($this), <TIME>);
    }


    public function onLoad(){
        $this->saveDefaultConfig();
    }


    public function onCommand(CommandSender $sender, Command $cmd, $label, array $args){
        switch($cmd->getName()){
            case "default":
            break;
        }
     return false;
    }
}