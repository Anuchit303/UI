<?php
namespace Anuchit@Naphon\UI;

use pocketmine\Server;
use pocketmine\scheduler\PluginTask;
use pocketmine\Player;

use Anuchit@Naphon\UI\Main;



class Task1 extends PluginTask {


   public function __construct(Main $main) {
        parent::__construct($main);
        $this->main = $main;
        $this->server = $main->getServer();
    }


   public function onRun($tick) {
        $this->main->getLogger()->debug("Task " . get_class($this) . " is running on $tick"); 
    }


}